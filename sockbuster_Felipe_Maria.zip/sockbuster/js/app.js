(()=>{
const $=s=>document.querySelector(s),K='sockbuster_v2',TALLAS=['S','M','L','XL'];
const COL=['Ciencia Ficción','Terror 80s','Series de Drama','Animación'];
const fmt=n=>'$'+Number(n).toLocaleString('es-CL');
const esc=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mk=(id,nombre,col,precio,em,obra,s)=>({id,nombre,col,precio,em,obra,stock:{S:s[0],M:s[1],L:s[2],XL:s[3]},res:[]});
const SEED=[
mk(1,'Star Wars: Imperio',0,12990,'🚀','Star Wars (película)',[2,3,2,1]),
mk(2,'Alien: Octavo Pasajero',0,11990,'👽','Alien (película)',[4,6,5,3]),
mk(3,'Volver al Futuro',0,10990,'🚗','Back to the Future (película)',[5,8,6,4]),
mk(4,'Pesadilla: Freddy',1,11490,'🔪','A Nightmare on Elm Street (película)',[1,3,2,0]),
mk(5,'Cazafantasmas',1,10990,'👻','Ghostbusters (película)',[6,7,6,4]),
mk(6,'It: Pennywise',1,11990,'🎈','It (película)',[3,5,4,2]),
mk(7,'Breaking Bad: Heisenberg',2,12490,'🧪','Breaking Bad (serie)',[2,4,3,1]),
mk(8,'Stranger Things: Hawkins',2,11990,'🔦','Stranger Things (serie)',[5,8,6,3]),
mk(9,'Juego de Tronos',2,12990,'🐉','Game of Thrones (serie)',[3,5,5,2]),
mk(10,'Los Simpson: Homero',3,9990,'🍩','The Simpsons (serie)',[7,9,6,4]),
mk(11,'Toy Story: Woody',3,9490,'🤠','Toy Story (película)',[6,6,5,3]),
mk(12,'Pokémon: Pikachu',3,10490,'⚡','Pokémon (serie)',[1,2,2,1])];
let st=Object.assign({prods:SEED,cart:[],user:null},(()=>{try{return JSON.parse(localStorage.getItem(K))||{}}catch(e){return{}}})());
const save=()=>{try{localStorage.setItem(K,JSON.stringify(st))}catch(e){}};
const q=new URLSearchParams(location.search).get('col');
const f={q:'',low:false,col:q!==null&&COL[q]?+q:-1,talla:'',max:15000};
const GR=['linear-gradient(135deg,#CC1F2F,#2B2F33)','linear-gradient(135deg,#9AA1A8,#2B2F33)','linear-gradient(135deg,#2B2F33,#CC1F2F 80%)'];
const emo=p=>`<span class="em" role="img" aria-label="${esc(p.nombre)}">${p.em}</span>`;
const total=p=>TALLAS.reduce((a,t)=>a+p.stock[t],0);
const avg=p=>p.res.length?p.res.reduce((a,r)=>a+r.e,0)/p.res.length:0;
const stars=n=>'★'.repeat(Math.round(n))+'☆'.repeat(5-Math.round(n));
const byId=id=>st.prods.find(p=>p.id===id);
let tm;const toast=(t,e)=>{const m=$('#msg');m.textContent=t;m.style.display='block';m.style.borderLeftColor=e?'#CC1F2F':'#9AA1A8';clearTimeout(tm);tm=setTimeout(()=>m.style.display='none',3200)};
const jwt=u=>btoa(JSON.stringify({alg:'HS256',typ:'JWT'}))+'.'+btoa(JSON.stringify({sub:u.email,rol:u.rol,exp:Date.now()+36e5}))+'.firma-simulada';
const valid=()=>{try{return st.user&&JSON.parse(atob(st.user.token.split('.')[1])).exp>Date.now()}catch(e){return false}};
const USERS=[{email:'cliente@sockbuster.cl',pass:'1234',nombre:'Cliente Demo',rol:'CLIENTE'},{email:'admin@sockbuster.cl',pass:'admin123',nombre:'Administrador',rol:'ADMIN'}];
const dlg=$('#dlg');
const show=h=>{dlg.innerHTML=h+'<p><button class="btn alt sm" data-a="close">Cerrar</button></p>';if(!dlg.open)dlg.showModal()};

function bar(){
 const n=st.cart.reduce((a,i)=>a+i.q,0),u=valid()?st.user:null;
 $('#bar').innerHTML=(u?`<span class="muted">${esc(u.nombre)}</span>${u.rol==='ADMIN'?'<button class="nb" data-a="admin">🛠️ Administrar</button>':''}<button class="nb" data-a="logout">Salir</button>`:'<button class="nb" data-a="login">🔑 Ingresar</button>')+`<button class="btn sm" data-a="cart">🛒 Carrito (${n})</button>`;
}
function chips(){
 $('#chips').innerHTML=['🧦 Todas','🚀 '+COL[0],'🔪 '+COL[1],'🎭 '+COL[2],'🍩 '+COL[3]].map((c,i)=>`<button class="chip" data-a="col" data-id="${i-1}" aria-pressed="${f.col===i-1}">${c}</button>`).join('');
}
function list(){
 const r=st.prods.filter(p=>(f.col<0||p.col===f.col)&&(!f.talla||p.stock[f.talla]>0)&&p.precio<=f.max&&(!f.q||(p.nombre+' '+p.obra).toLowerCase().includes(f.q))&&(!f.low||total(p)<=12));
 $('#count').textContent=r.length+' modelos encontrados';
 $('#grid').innerHTML=r.length?r.map(p=>{
  const ts=TALLAS.filter(t=>p.stock[t]>0);
  return `<article class="card"><div class="img" style="background:${GR[(p.id+p.col)%3]}">${emo(p)}<span class="tag">${COL[p.col]}</span>${total(p)<=8?`<span class="low">¡Quedan ${total(p)}!</span>`:''}</div><div class="b"><h3>${esc(p.nombre)}</h3><span class="muted">${esc(p.obra)}</span>
  <span class="price">${fmt(p.precio)}</span><span class="muted">Stock: ${total(p)} · Tallas: ${ts.join(', ')||'agotado'}</span>
  <span aria-label="Valoración">${p.res.length?stars(avg(p))+' ('+p.res.length+')':'<span class="muted">Sin reseñas</span>'}</span>
  ${ts.length?`<div class="row"><select aria-label="Talla de ${esc(p.nombre)}" id="t${p.id}">${ts.map(t=>`<option>${t}</option>`).join('')}</select><button class="btn sm" data-a="add" data-id="${p.id}">Agregar</button></div>`:'<span class="err">Agotado</span>'}
  <button class="btn alt sm" data-a="det" data-id="${p.id}">Ver detalle y reseñas</button></div></article>`}).join(''):'<p>No hay calcetines con esos filtros. Prueba otra talla o sube el precio máximo.</p>';
}
function cart(){
 const c=$('#cart');let t=0;
 const rows=st.cart.map((i,ix)=>{const p=byId(i.id);t+=p.precio*i.q;return `<div class="line"><div><b>${esc(p.nombre)}</b> (${i.t})<br><span class="muted">${fmt(p.precio)} c/u</span></div><div class="row"><button class="btn alt sm" data-a="dec" data-id="${ix}" aria-label="Quitar uno">−</button>${i.q}<button class="btn alt sm" data-a="inc" data-id="${ix}" aria-label="Agregar uno">+</button><button class="btn alt sm danger" data-a="rm" data-id="${ix}" aria-label="Eliminar">✕</button></div></div>`}).join('');
 c.innerHTML=`<h2>Tu carrito</h2>${rows||'<p>Está vacío. Agrega calcetines desde el catálogo.</p>'}<p><b>Total: ${fmt(t)}</b></p><div class="row"><button class="btn" data-a="checkout">Confirmar compra</button><button class="btn alt" data-a="cart">Seguir comprando</button></div>`;
}
const refresh=()=>{bar();list();cart();save()};

function detail(id){
 const p=byId(id);
 show(`<h2>${esc(p.nombre)}</h2><div class="row" style="align-items:flex-start"><div class="big">${emo(p)}</div><div><span class="tag">${COL[p.col]}</span><p class="muted">Inspirado en: ${esc(p.obra)}</p><p class="price">${fmt(p.precio)}</p>
 <p>Stock por talla: ${TALLAS.map(t=>t+': '+p.stock[t]).join(' · ')}</p></div></div>
 <h3>Reseñas ${p.res.length?stars(avg(p))+' '+avg(p).toFixed(1):''}</h3>
 ${p.res.map(r=>`<p><b>${esc(r.n)}</b> ${stars(r.e)}<br>${esc(r.c)}</p>`).join('')||'<p class="muted">Aún no hay reseñas.</p>'}
 ${valid()?`<form data-f="resena" data-id="${id}"><label>Valoración<select name="e">${[5,4,3,2,1].map(n=>`<option value="${n}">${n} ${stars(n)}</option>`).join('')}</select></label><label>Comentario<textarea name="c" rows="3" required maxlength="300"></textarea></label><button class="btn">Publicar reseña</button></form>`:'<p><button class="btn sm" data-a="login">Ingresa para publicar una reseña</button></p>'}`);
}
function login(){show(`<h2>Ingresar</h2><form data-f="login"><label>Correo<input name="email" type="email" required></label><label>Contraseña<input name="pass" type="password" required></label><button class="btn">Ingresar</button></form><p class="muted">Demo: cliente@sockbuster.cl / 1234 · admin@sockbuster.cl / admin123. La sesión usa un token JWT simulado.</p>`)}
function admin(){
 if(!valid()||st.user.rol!=='ADMIN'){show('<h2>403 Acceso denegado</h2><p>Esta función requiere un token JWT con rol ADMIN.</p>');return}
 show(`<h2>Panel de administración</h2><p class="muted">Token: ${esc(st.user.token.slice(0,28))}…</p>
 <div class="tblw"><table><tr><th>Modelo</th><th>Precio</th>${TALLAS.map(t=>'<th>'+t+'</th>').join('')}<th></th></tr>
 ${st.prods.map(p=>`<tr data-p="${p.id}"><td>${esc(p.nombre)}</td><td><input type="number" min="0" step="10" value="${p.precio}" aria-label="Precio"></td>${TALLAS.map(t=>`<td><input type="number" min="0" value="${p.stock[t]}" aria-label="Stock ${t}"></td>`).join('')}<td><button class="btn sm" data-a="saveP" data-id="${p.id}">Guardar</button></td></tr>`).join('')}</table></div>
 <h3 style="margin-top:20px">Registrar nuevo modelo</h3><form data-f="nuevo"><label>Nombre<input name="n" required></label><label>Película o serie asociada<input name="o" required></label><label>Colección<select name="c">${COL.map((c,i)=>`<option value="${i}">${c}</option>`).join('')}</select></label><label>Precio (CLP)<input name="p" type="number" min="1" required></label><label>Stock inicial por talla<input name="s" type="number" min="0" value="5" required></label><button class="btn">Registrar</button></form>`);
}
function checkout(){
 if(!st.cart.length){toast('El carrito está vacío',1);return}
 if(!valid()){$('#cart').classList.remove('open');toast('Inicia sesión para confirmar la compra',1);login();return}
 const bad=st.cart.find(i=>byId(i.id).stock[i.t]<i.q);
 if(bad){toast('Stock insuficiente para '+byId(bad.id).nombre+' ('+bad.t+')',1);return}
 let t=0;const lines=st.cart.map(i=>{const p=byId(i.id);p.stock[i.t]-=i.q;t+=p.precio*i.q;return `<tr><td>${esc(p.nombre)}</td><td>${i.t}</td><td>${i.q}</td><td>${fmt(p.precio*i.q)}</td></tr>`}).join('');
 const id=crypto.randomUUID?crypto.randomUUID():'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>(Math.random()*16|0).toString(16));
 st.cart=[];$('#cart').classList.remove('open');refresh();
 show(`<h2>Pedido confirmado</h2><p class="ok">Pago simulado aprobado.</p><p>Identificador del pedido:<br><b>${id}</b></p><div class="tblw"><table><tr><th>Modelo</th><th>Talla</th><th>Cant.</th><th>Subtotal</th></tr>${lines}</table></div><p><b>Total: ${fmt(t)}</b></p>`);
}
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,id=+b.dataset.id;
 if(a==='col'){f.col=id;chips();list()}
 else if(a==='add'){const t=$('#t'+id).value,i=st.cart.find(x=>x.id===id&&x.t===t),p=byId(id);if((i?i.q:0)+1>p.stock[t]){toast('No hay más stock en talla '+t,1);return}i?i.q++:st.cart.push({id,t,q:1});refresh();const cb=$('#bar .btn');cb.classList.add('bump');toast(p.em+' '+p.nombre+' (talla '+t+') agregado')}
 else if(a==='inc'){const i=st.cart[id];if(i.q<byId(i.id).stock[i.t])i.q++;else toast('Sin más stock',1);refresh()}
 else if(a==='dec'){const i=st.cart[id];i.q>1?i.q--:st.cart.splice(id,1);refresh()}
 else if(a==='rm'){st.cart.splice(id,1);refresh()}
 else if(a==='cart')$('#cart').classList.toggle('open');
 else if(a==='rand')detail(st.prods[Math.floor(Math.random()*st.prods.length)].id);
 else if(a==='low'){f.low=!f.low;b.setAttribute('aria-checked',f.low);list()}
 else if(a==='det')detail(id);else if(a==='login')login();else if(a==='admin')admin();
 else if(a==='logout'){st.user=null;refresh();toast('Sesión cerrada')}
 else if(a==='checkout')checkout();
 else if(a==='close')dlg.close();
 else if(a==='saveP'){if(!valid()||st.user.rol!=='ADMIN'){toast('401: token inválido o expirado',1);return}
  const tr=b.closest('tr'),v=[...tr.querySelectorAll('input')].map(x=>Math.max(0,+x.value||0)),p=byId(id);p.precio=v[0];TALLAS.forEach((t,k)=>p.stock[t]=v[k+1]);refresh();toast('Cambios guardados')}
});
document.addEventListener('submit',e=>{
 const fm=e.target.dataset.f;if(!fm)return;e.preventDefault();const d=Object.fromEntries(new FormData(e.target));
 if(fm==='login'){const u=USERS.find(x=>x.email===d.email&&x.pass===d.pass);if(!u){toast('401: correo o contraseña incorrectos',1);return}
  st.user={email:u.email,nombre:u.nombre,rol:u.rol,token:jwt(u)};dlg.close();refresh();toast('Bienvenido, '+u.nombre)}
 else if(fm==='resena'){if(!valid()){toast('401: inicia sesión',1);return}const p=byId(+e.target.dataset.id),n=+d.e;if(n<1||n>5){toast('Elige de 1 a 5 estrellas',1);return}
  p.res.push({n:st.user.nombre,e:n,c:d.c});refresh();detail(p.id);toast('Reseña publicada')}
 else if(fm==='nuevo'){if(!valid()||st.user.rol!=='ADMIN'){toast('403: sin permiso',1);return}
  const s=Math.max(0,+d.s),pal=['🧦','🎬','⭐','🎞️','🍿'][Math.floor(Math.random()*5)];
  st.prods.push(mk(Math.max(...st.prods.map(x=>x.id))+1,d.n,+d.c,+d.p,pal,d.o,[s,s,s,s]));refresh();admin();toast('Modelo registrado')}
});
$('#fQ').addEventListener('input',e=>{f.q=e.target.value.trim().toLowerCase();list()});
$('#fTalla').addEventListener('change',e=>{f.talla=e.target.value;list()});
$('#fMax').addEventListener('input',e=>{f.max=+e.target.value;$('#fOut').textContent=fmt(f.max);list()});
$('#fOut').textContent=fmt(f.max);
chips();refresh();
if(new URLSearchParams(location.search).get('sorpresa'))detail(st.prods[Math.floor(Math.random()*st.prods.length)].id);
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#cart').classList.remove('open')});
})();
